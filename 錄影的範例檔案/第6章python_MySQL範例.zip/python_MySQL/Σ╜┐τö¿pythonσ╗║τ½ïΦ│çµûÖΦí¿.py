import pymysql.cursors
from pymysql import Error

def create_connection():
    connection = None
    try:
        connection = pymysql.connect(host='localhost',
                                     user='root',
                                     password='12341234',
                                     database='world',
                                     charset='utf8mb4',
                                     cursorclass=pymysql.cursors.DictCursor)
    except Error as e:
        print(e)
        return None
    return  connection

def create_table(conn,create_sql):

    with conn.cursor() as cursor:
        cursor.execute(create_sql)



    conn.commit()

if __name__ == '__main__':
    sql_create_projects = '''
    CREATE TABLE IF NOT EXISTS projects(
	id INTEGER PRIMARY KEY AUTO_INCREMENT,
    name TEXT NOT NULL,
    begin_date TEXT,
    end_date TEXT
    );
    '''

    sql_create_task = '''
    CREATE TABLE IF NOT EXISTS task(
	id INTEGER PRIMARY KEY AUTO_INCREMENT,
    name TEXT NOT NULL,
    priority INTEGER,
    project_id INTEGER NOT NULL,
    status_id INTEGER NOT NULL,
    begin_date TEXT,
    end_date TEXT,
    FOREIGN KEY(project_id) REFERENCES projects(id)
    );
    '''

    conn = create_connection()
    if conn is not None:
        with conn:
            create_table(conn,sql_create_projects)
            create_table(conn,sql_create_task)


