import pymysql.cursors
from pymysql import Error

def create_connection():
    connection = None
    try:
        connection = pymysql.connect(host='localhost',
                                     user='root',
                                     password='12341234',
                                     database='world',
                                     charset='utf8mb4',
                                     cursorclass=pymysql.cursors.DictCursor)
    except Error as e:
        print(e)
        return None
    return  connection

def create_table(conn,create_sql):

    with conn.cursor() as cursor:
        cursor.execute(create_sql)
    conn.commit()

def insert_project(conn,project):
    sql_project = '''
    INSERT INTO projects(name,begin_date,end_date)
    VALUES(%s,%s,%s)
    '''
    with conn.cursor() as cursor:
        cursor.execute(sql_project,project)
    conn.commit()
    return  cursor.lastrowid


def insert_task(conn,task):
    sql_task = '''
    INSERT INTO task(name,priority, status_id, project_id,begin_date,end_date)
    VALUES(%s,%s,%s,%s,%s,%s)
    '''
    with conn.cursor() as cursor:
        cursor.execute(sql_task,task)
    conn.commit()

def update_task(conn, task):
    sql = '''
    UPDATE task
    SET priority = %s,
	begin_date = %s,
    end_date = %s
    WHERE id=%s;
    '''

    with conn.cursor() as cursor:
        cursor.execute(sql,task)
    conn.commit()

def select_all_tasks(conn):
    sql = '''
    SELECT *
    FROM task
    '''
    with conn.cursor() as cursor:
        cursor.execute(sql)
        rows = cursor.fetchall()
        for row in rows:
            print(row)

def select_task_by_priority(conn,priority):
    sql = '''
    SELECT *
    FROM task
    WHERE priority = %s
    '''
    with conn.cursor() as cursor:
        cursor.execute(sql,(priority,))
        rows = cursor.fetchall()
        for row in rows:
            print(row)

def delete_task(conn, id):
    sql = '''
    DELETE FROM task
    WHERE id=%s
    '''
    with conn.cursor() as cursor:
        cursor.execute(sql,(id,))
    conn.commit()


if __name__ == '__main__':
    conn = create_connection()
    if conn is not None:
        with conn:
            delete_task(conn,2)

