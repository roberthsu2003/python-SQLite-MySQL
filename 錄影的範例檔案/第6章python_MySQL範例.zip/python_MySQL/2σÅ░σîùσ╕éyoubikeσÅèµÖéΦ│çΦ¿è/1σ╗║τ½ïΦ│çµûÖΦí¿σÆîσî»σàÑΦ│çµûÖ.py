import dataSource

if __name__ == "__main__":
    youbikeInfo = dataSource.loadDataFromYouBikeTP()
    dataSource.update_data(youbikeInfo)