#台北市串接Youbike網址
#https://tcgbusfs.blob.core.windows.net/blobyoubike/YouBikeTP.json
'''
sno(站點代號)、sna(場站中文名稱)、tot(場站總停車格)、sbi(場站目前車輛數量)、sarea(場站區域)、mday(資料更新時間)、lat(緯度)、lng(經度)、ar(地點)、sareaen(場站區域英文)、snaen(場站名稱英文)、aren(地址英文)、bemp(空位數量)、act(全站禁用狀態)
'''

import requests
import pymysql.cursors
from pymysql import Error

def create_connection():
    connection = None
    try:
        connection = pymysql.connect(
            host='localhost',
            user='root',
            password='12341234',
            database='youbike',
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor
        )
    except Error as e:
        print(e)
    return connection

def create_table(conn):
    sql = '''
    CREATE TABLE IF NOT EXISTS youbike(
	id BIGINT AUTO_INCREMENT,
    sno VARCHAR(6) NOT NULL,
    sna VARCHAR(50),
    tot SMALLINT UNSIGNED,
    sbi SMALLINT UNSIGNED,
    sarea VARCHAR(10),
    mday DATETIME,
    lat REAL,
    lng REAL,
    ar VARCHAR(100),
    bemp SMALLINT UNSIGNED,
    act TINYINT,
    PRIMARY KEY(id),
    UNIQUE(sno)
    );
    '''

    with conn.cursor() as cursor:
        try:
            cursor.execute(sql)
        except Error as e:
            print(e)

def update_data(downloadData):
    def change_datetime_format(d):
        from datetime import datetime
        datetime_object = datetime.strptime(d,'%Y%m%d%H%M%S')
        return datetime_object.strftime("%Y-%m-%d %H:%M:%S")

    conn = create_connection()
    if conn is not None:
        with conn:
            create_table(conn)
            replace_into_sql = '''
            REPLACE INTO youbike(sno,sna,tot,sbi,sarea,mday,lat,lng,ar,bemp,act)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            '''
            with conn.cursor() as cursor:
                for item in downloadData:
                    sno = item['sno']
                    sna = item['sna']
                    tot = int(item['tot'])
                    sbi = int(item['sbi'])
                    sarea = item['sarea']
                    mday = change_datetime_format(item['mday'])
                    lat = float(item['lat'])
                    lng = float(item['lng'])
                    ar = item['ar']
                    bemp = int(item['bemp'])
                    act = int(item['act'])
                    cursor.execute(replace_into_sql,(sno,sna,tot,sbi,sarea,mday,lat,lng,ar,bemp,act))
            conn.commit()

def get_siteInfo():
    conn = create_connection()
    select_sql = '''
    select * from youbike
    '''
    with conn:
        with conn.cursor() as cursor:
            cursor.execute(select_sql)
            rows = cursor.fetchall()

    return rows

def get_count_of_normal():
    conn = create_connection()
    sql = '''
    SELECT count(*) as 正常數量
    FROM youbike
    WHERE act = 1 AND sbi > 3 AND bemp > 3
    '''

    with conn:
        with conn.cursor() as cursor:
            try:
                cursor.execute(sql)
                row = cursor.fetchone()
            except Error as e:
                print(e)

    return row['正常數量']

def get_list_of_normal():
    conn = create_connection()
    sql = '''
        SELECT  sna,tot,sbi,bemp
        FROM youbike
        WHERE act = 1 AND sbi > 3 AND bemp > 3
    '''
    with conn:
        with conn.cursor() as cursor:
            try:
                cursor.execute(sql)
                rows = cursor.fetchall()
            except Error as e:
                print(e)
    return rows

def get_count_of_less_bike():
    conn = create_connection()
    sql = '''
        SELECT count(*) as 正常數量
        FROM youbike
        WHERE act = 1 AND sbi <=3
        '''

    with conn:
        with conn.cursor() as cursor:
            try:
                cursor.execute(sql)
                row = cursor.fetchone()
            except Error as e:
                print(e)

    return row['正常數量']

def get_list_of_less_bike():
    conn = create_connection()
    sql = '''
        SELECT  sna,tot,sbi,bemp
        FROM youbike
        WHERE act = 1 AND sbi <= 3
    '''
    with conn:
        with conn.cursor() as cursor:
            try:
                cursor.execute(sql)
                rows = cursor.fetchall()
            except Error as e:
                print(e)
    return rows

def get_count_of_less_stop():
    conn = create_connection()
    sql = '''
        SELECT count(*) as 正常數量
        FROM youbike
        WHERE act = 1 AND bemp <=3
        '''

    with conn:
        with conn.cursor() as cursor:
            try:
                cursor.execute(sql)
                row = cursor.fetchone()
            except Error as e:
                print(e)

    return row['正常數量']

def get_list_of_less_stop():
    conn = create_connection()
    sql = '''
        SELECT  sna,tot,sbi,bemp
        FROM youbike
        WHERE act = 1 AND bemp <= 3
    '''
    with conn:
        with conn.cursor() as cursor:
            try:
                cursor.execute(sql)
                rows = cursor.fetchall()
            except Error as e:
                print(e)
    return rows


def loadDataFromYouBikeTP():
    url = 'https://tcgbusfs.blob.core.windows.net/blobyoubike/YouBikeTP.json'
    response = requests.get(url)
    response.encoding = 'utf-8'
    downloadData = response.json()
    downloadData = downloadData['retVal']
    youbikeData = list(downloadData.values())
    return youbikeData

