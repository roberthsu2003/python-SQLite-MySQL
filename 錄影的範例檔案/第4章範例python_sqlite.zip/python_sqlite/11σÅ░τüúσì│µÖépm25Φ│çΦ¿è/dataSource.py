import requests
import sqlite3
from sqlite3 import Error

def __create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)
        return
    return conn

def __create_table_pm25(conn):
    sql = '''
    CREATE TABLE IF NOT EXISTS pm25(
		id INTEGER PRIMARY KEY,
		站點 TEXT,
		城市 TEXT,
		pm25 REAL,
		日期 TEXT,
		單位 TEXT,
		UNIQUE(站點,日期)
    );
    '''
    cursor = conn.cursor()
    cursor.execute(sql)

def __replace_pm25(conn,values):
    sql='''
    INSERT OR REPLACE INTO pm25(站點,城市,pm25,日期,單位)
    VALUES (?,?,?,?,?)
    '''
    cursor = conn.cursor()
    cursor.execute(sql,values)
    conn.commit()

def __saveToDataBase(datas):
    conn = __create_connection('pm25.db')
    if conn is not None:
        with conn:
            __create_table_pm25(conn)
            for value in datas:
                __replace_pm25(conn,value)
        print("已經更新資料")





def __downloadData():
    urlpath = 'https://data.epa.gov.tw/api/v1/aqx_p_02?limit=1000&api_key=9be7b239-557b-4c10-9775-78cadfc555e9&sort=ImportDate%20desc&format=json'
    response = requests.get(urlpath)
    def stringToFloat(s):
        try:
            return float(s)
        except:
            return 999.0

    if response.status_code == 200:
        print('下載成功')
        jsonData = response.json()
        datas = jsonData['records']
        downloadData = [(
                        dic['Site'],
                        dic['county'],
                        stringToFloat(dic['PM25']),
                        dic['DataCreationDate'],
                        dic['ItemUnit'],
                         )for dic in datas]
        return downloadData

def get_city_name():
    conn = __create_connection('pm25.db')
    sql = '''
    SELECT DISTINCT 城市
    FROM pm25
    '''
    with conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        rows = cursor.fetchall()
        city_name_list = [row[0] for row in rows]
        return city_name_list

def get_site_name(city):
    conn = __create_connection('pm25.db')
    sql = '''
    SELECT DISTINCT 站點
    FROM pm25
    WHERE 城市= ?
    '''
    with conn:
        cursor = conn.cursor()
        cursor.execute(sql,(city,))
        rows = cursor.fetchall()
        sites = [item[0] for item in rows]
        return sites

def get_site_info(site):
    conn = __create_connection('pm25.db')
    sql = '''
    SELECT *
    FROM pm25
    WHERE 站點 = ?
    ORDER BY 日期 DESC
    LIMIT 100
    '''

    with conn:
        cursor = conn.cursor()
        cursor.execute(sql,(site,))
        rows = cursor.fetchone()
        return rows

def get_better():
    conn = __create_connection('pm25.db')
    sql = '''
    SELECT *
    FROM pm25
    WHERE pm25 <= 35  AND 日期 = (SELECT max(日期) FROM pm25)
    '''
    with conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        rows =  cursor.fetchall()

    return rows

def get_normal():
    conn = __create_connection('pm25.db')
    sql = '''
    SELECT *
    FROM pm25
    WHERE (pm25 BETWEEN 35 AND 53) AND 日期 = (SELECT max(日期) FROM pm25)
    '''
    with conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        rows =  cursor.fetchall()

    return rows

def get_bad():
    conn = __create_connection('pm25.db')
    sql = '''
    SELECT *
    FROM pm25
    WHERE pm25 > 53 AND 日期 = (SELECT max(日期) FROM pm25)
    '''
    with conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        rows =  cursor.fetchall()

    return rows



def download_save_to_DataBase():
    downloadData = __downloadData()
    __saveToDataBase(downloadData)
