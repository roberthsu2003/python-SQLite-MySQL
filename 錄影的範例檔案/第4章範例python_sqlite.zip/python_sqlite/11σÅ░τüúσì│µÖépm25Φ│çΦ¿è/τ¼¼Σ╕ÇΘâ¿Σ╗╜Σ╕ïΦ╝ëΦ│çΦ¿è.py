import dataSource

if __name__ == "__main__":
    downloadData = dataSource.downloadData()
    for one in downloadData:
        print(one)
