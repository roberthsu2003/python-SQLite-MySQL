import dataSource

if __name__ == "__main__":
    downloadData = dataSource.downloadData()
    dataSource.saveToDataBase(downloadData)
