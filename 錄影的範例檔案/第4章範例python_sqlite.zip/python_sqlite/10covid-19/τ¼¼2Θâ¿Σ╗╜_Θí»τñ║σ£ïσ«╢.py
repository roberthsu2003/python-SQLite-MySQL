import tkinter as tk
from tkinter import ttk
from tkinter.messagebox import showinfo
from source import get_continent,get_country_by_continent

window = tk.Tk()
#修改視窗大小
#window.geometry('300x200')
window.resizable(False, False)
window.title('選擇世界洲名')

#建立leftFrame
leftFrame = ttk.LabelFrame(window,text="洲名")
leftFrame.grid(column=0,row=0,padx=20,pady=20,sticky="N")

#label顯示標題
label = ttk.Label(leftFrame,text="請選擇洲名")
label.pack(fill=tk.X, padx=5, pady=5)

#建立下拉式表單
selected_continent = tk.StringVar()
selected_continent.set("請選擇")
combobox = ttk.Combobox(leftFrame,textvariable=selected_continent)
combobox.pack()



#提供資料
combobox['values'] = get_continent()

#預防使用者更改文字
combobox['state'] = 'readonly'

#使用者選擇的動作
def user_change(event):
    listbox.configure(state=tk.NORMAL)
    continent = selected_continent.get()
    print(get_country_by_continent(continent))
    choicesvar.set(get_country_by_continent(continent))


#combobox綁定事件
combobox.bind('<<ComboboxSelected>>',user_change)

#建立rightFrame
rightFrame = ttk.LabelFrame(window,text="國家名稱")
rightFrame.grid(column=1,row=0,padx=20,pady=20,sticky="N")

rightLabel = ttk.Label(rightFrame,text="請選擇國家名稱")
rightLabel.pack(fill=tk.X, padx=5, pady=5)

#建立listbox
choices = ['先選取洲']
choicesvar = tk.StringVar(value=choices)
listbox = tk.Listbox(rightFrame, height=10,listvariable=choicesvar,state=tk.DISABLED)
listbox.pack(padx=10, pady=10)

#listbox事件function
def select_country(event):
    country_index = listbox.curselection()
    if not country_index:
        return

    selected_country = listbox.get(country_index)
    print(selected_country)

#建立listbox綁定事件
listbox.bind("<<ListboxSelect>>",select_country)






window.mainloop()