import sqlite3
from sqlite3 import Error

def __create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)
        return None

    return conn

def __select_continent(conn):
    sql = """
    SELECT DISTINCT 洲名
    FROM world
    WHERE 洲名 IS NOT NULL
    """

    cursor = conn.cursor()
    cursor.execute(sql)
    rows = cursor.fetchall()
    continents = [row[0] for row in rows]
    return continents

def __selected_country_by_continent(conn, continent):
    sql = '''
    SELECT DISTINCT 國家
    FROM world
    WHERE 洲名=?
    '''
    cursor = conn.cursor()
    cursor.execute(sql,(continent,))
    rows = cursor.fetchall()
    selected_country = [row[0] for row in rows]
    return selected_country

def __selected_country_detail(conn,country_name):
    sql = '''
    SELECT 國家,日期,總確診數,新增確診數,總死亡數,新增死亡數
    FROM world
    WHERE 國家 = ?
    ORDER BY 日期 DESC
    '''
    cursor = conn.cursor()
    cursor.execute(sql,(country_name,))
    rows = cursor.fetchall()
    country_detials = [list(row) for row in rows]
    return country_detials

def get_continent():
    database = 'covid19.db'
    conn = __create_connection(database)
    if conn is not None:
        with conn:
            continents = __select_continent(conn)
            return continents
    else:
        return []

def get_country_by_continent(continent):
    database = 'covid19.db'
    conn = __create_connection(database)
    if conn is not None:
        with conn:
            countries = __selected_country_by_continent(conn,continent)
            return countries
    return []

def get_country_detailData(country):
    database = 'covid19.db'
    conn = __create_connection(database)
    if conn is not None:
        with conn:
            country_details = __selected_country_detail(conn,country)
            return country_details
    return []